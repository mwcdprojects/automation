import unittest
from apitest.apihelper import Apihelper

x = Apihelper()
class Testing(unittest.TestCase):
    def test_list_nonempty(self):
        assert len(x.get_results())!=0 , "The returned list is empty"
        if len(x.get_results())== 0:
            print "The returned list is empty"
        else:
            print "The returned list is not empty and its contents are: {}".format(x.get_results())

if __name__ == '__main__':
    unittest.main()
